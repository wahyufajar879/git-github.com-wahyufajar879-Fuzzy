<h1>Aplikasi Sistem Pendukung Keputusan Penerimaan Karyawan Fuzzy Tsukamoto</h1>
<p>Fuzzy Tsukamoto adalah adalah metode yang memiliki toleransi pada data dan sangat fleksibel. Kelebihan dari metode Tsukamoto yaitu bersifat intuitif dan dapat memberikan tanggapan berdasarkan informasi yang bersifat kualitatif, tidak akurat, dan ambigu</p>
<center><img src="karyawan1.jpeg"></center>